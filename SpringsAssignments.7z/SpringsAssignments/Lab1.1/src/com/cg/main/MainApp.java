package com.cg.main;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.beans.Employee;

public class MainApp {
	public static void main(String[] args) {

		Resource res=new ClassPathResource("spring.xml");
		BeanFactory factory=new XmlBeanFactory(res);
		
		Employee emp=(Employee) factory.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("--------------------------");
		
		System.out.println("Employee ID :"+emp.getEmployeeId());
		System.out.println("Employee Name :"+emp.getEmployeeName());
		System.out.println("Employee Salary :"+emp.getSalary());
		System.out.println("Employee BU :"+emp.getBusinessUnit());
		System.out.println("Employee Age :"+emp.getAge());
	}
}
