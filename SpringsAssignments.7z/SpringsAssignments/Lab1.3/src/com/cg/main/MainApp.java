package com.cg.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.beans.SBU;

import com.cg.beans.Employee;

public class MainApp {
	
	public static void main(String[] args) {
	
		
		Resource res=new ClassPathResource("spring.xml");
		BeanFactory springcontainer=new XmlBeanFactory(res);
		
		SBU sbu=(SBU) springcontainer.getBean("sbu",SBU.class);
		System.out.println("SBU Details");
		System.out.println("-----------------");
		
		System.out.println("SbuCode= "+sbu.getSbuCode());
		System.out.println("SbuName= "+sbu.getSbuName());
		System.out.println("SbuHead= "+sbu.getSbuHead());
		
		System.out.println("Employee Details");
		System.out.println("----------------------");
		System.out.println(sbu.getEmpList());

		
		
		
	
	}

}
