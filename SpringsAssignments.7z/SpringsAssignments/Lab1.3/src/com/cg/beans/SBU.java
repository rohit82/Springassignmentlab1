package com.cg.beans;

import java.util.List;

public class SBU {

	private String sbuCode;
	private String sbuName;
	private String sbuHead;
	private List<Employee> empList;
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SBU(String sbuCode, String sbuName, String sbuHead,
			List<Employee> empList) {
		super();
		this.sbuCode = sbuCode;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.empList = empList;
	}
	/**
	 * @return the sbuCode
	 */
	public String getSbuCode() {
		return sbuCode;
	}
	/**
	 * @param sbuCode the sbuCode to set
	 */
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	/**
	 * @return the sbuName
	 */
	public String getSbuName() {
		return sbuName;
	}
	/**
	 * @param sbuName the sbuName to set
	 */
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	/**
	 * @return the sbuHead
	 */
	public String getSbuHead() {
		return sbuHead;
	}
	/**
	 * @param sbuHead the sbuHead to set
	 */
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	/**
	 * @return the empList
	 */
	public List<Employee> getEmpList() {
		return empList;
	}
	/**
	 * @param empList the empList to set
	 */
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName
				+ ", sbuHead=" + sbuHead + ", empList=" + empList + "]";
	}

	
	
	
}
