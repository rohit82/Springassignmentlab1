package com.cg.beans;

import java.io.Serializable;

public class SBU implements Serializable{

	private int sbuId;
	private String subName;
	private String sbuHead;
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SBU(int sbuId, String subName, String sbuHead) {
		super();
		this.sbuId = sbuId;
		this.subName = subName;
		this.sbuHead = sbuHead;
	}
	/**
	 * @return the sbuId
	 */
	public int getSbuId() {
		return sbuId;
	}
	/**
	 * @param sbuId the sbuId to set
	 */
	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}
	/**
	 * @return the subName
	 */
	public String getSubName() {
		return subName;
	}
	/**
	 * @param subName the subName to set
	 */
	public void setSubName(String subName) {
		this.subName = subName;
	}
	/**
	 * @return the sbuHead
	 */
	public String getSbuHead() {
		return sbuHead;
	}
	/**
	 * @param sbuHead the sbuHead to set
	 */
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", subName=" + subName + ", sbuHead="
				+ sbuHead + "]";
	}
	
	public SBU getSbuDetails(SBU sbud)
	{
		return sbud.getSbuDetails(this);
		
	}
	
}
