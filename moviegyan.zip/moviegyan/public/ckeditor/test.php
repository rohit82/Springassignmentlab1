

    <script type="text/javascript" src="/ckeditor/ckeditor.js"></script>
    <textarea class="ckeditor" name="editor"></textarea>

