<?php 
class Admin_Home extends Controller
{
	public function index()
	{	
		if(!isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Login");
		}
		require APP . 'view/_templates/mheader.php';
		require APP . 'view/Admin/admin_home.php';
		require APP . 'view/_templates/mfooter.php';
	}
	
	public function logout()
	{
		$callmodel=$this->loadModel("admin_model");
		$outstatus=$callmodel->logout();
		if($outstatus==true)
		{
			$_SESSION['message']['general']="You are logout successfully";
			header("location:". URL ."Login");
		}
		else
		{
			$_SESSION['message']['general']="You don't have permission that page";
			header("location:". URL ."Login");
		}
	}
	
	public function mymovies()
	{
		if(!isset($_SESSION['moviegyan']['id']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page";
			header("location:". URL ."Login");
		}
		else
		{
			$callmodel=$this->loadModel("article_model");
			$articles=$callmodel->get_my_articles($_SESSION['moviegyan']['id']);
			//var_dump($articles);exit;
			require APP . 'view/_templates/mheader.php';
			require APP . 'view/Articles/my_articles.php';
			require APP . 'view/_templates/mfooter.php';
		}
	}
	
	public function Admin_info_edit()
	{
		if(!isset($_SESSION['moviegyan']['id']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page";
			header("location:". URL ."Login");
		}
		else
		{
			$callmodel=$this->loadModel("unique_model");
			$data=$callmodel->get_particular_data('usermaster','id',$_SESSION['moviegyan']['id']);
			//var_dump($data);exit();
			require APP . 'view/_templates/mheader.php';
			require APP . 'view/Admin/admin_edit.php';
			require APP . 'view/_templates/mfooter.php';
		}
	}

	public function checkmail($email)
	{
		//var_dump($email);exit();
		$callmodel=$this->loadModel("admin_model");
		$data=$callmodel->checkmail('usermaster','email','id',$email,$_SESSION['moviegyan']['id']);
		if($data==false)
		{
			echo "<font color='red'>This Email already exists</font>";
		}
	}

	public function update_admin()
	{
		if(!isset($_SESSION['moviegyan']['id']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page";
			header("location:". URL ."Login");
		}
		else
		{
			if(isset($_POST['save'])) 
			{
				//var_dump($_POST);exit();
				extract($_POST);
				$callmodel=$this->loadModel("admin_model");
				$mailstatus=$callmodel->checkmail('usermaster','email','id',$email,$_SESSION['moviegyan']['id']);
				if($mailstatus==true)
				{
					$updatestastus=$callmodel->update_user_admin($fname,$lname,$email,$_SESSION['moviegyan']['id']);
					$_SESSION['message']['general']="<b>Updated successfully </b>";
					header("location:". URL ."Admin_Home/Admin_info_edit");
				}
				else
				{
					$_SESSION['message']['general']="<font color='red'>".$email."</font> already exists !!";
					header("location:". URL ."Admin_Home/Admin_info_edit");
				}
			}
		}
	}
}
?>