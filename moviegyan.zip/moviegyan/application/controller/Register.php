<?php 
class Register extends Controller
{
	public function index()
	{
		if(!isset($_SESSION['moviegyan']['id']))
		{
		$callmodel=$this->loadModel("unique_model");
		$questions=$callmodel->get_all_data('security_question');
		//var_dump($questions);exit;
		require APP . 'view/_templates/mheader.php';
		require APP . 'view/register/register_index.php';
		require APP . 'view/_templates/mfooter.php';
		}
		else
		{
			header("location:". URL ."Admin_Home");
		}
	}
	
	public function checkemail()
	{
		if(isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Admin_Home");
		}
		$callmodel=$this->loadModel("register_model");
		$mailstatus=$callmodel->checkEmail($_POST['ajemail']);
		if($mailstatus==true)
		{
			echo $_SESSION['message']['already_avail'];
			unset($_SESSION['message']['already_avail']);
		}
	}
	
	
	public function user_register_data()
	{
		if(isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Admin_Home");
		}
		//var_dump($_POST);exit;
		if(isset($_POST['register']))
		{
			extract($_POST);
			$callmodel=$this->loadModel("register_model");
			$mailstatus=$callmodel->checkEmail($email);
			if($mailstatus==true)
			{
				header("location:". URL ."Register");	
			}
			else
			{
				$model=$this->loadModel("unique_model");
				$question=$model->get_particular_data('security_question','qid',$question_id);
				//var_dump($question);exit;
				require APP . 'view/_templates/mheader.php';
				require APP . 'view/register/register_data.php';
				require APP . 'view/_templates/mfooter.php';	
			}
		}
		else
		{
			header("location:". URL ."Register");
		}
	}
	
	
	public function register_now()
	{
		if(isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Admin_Home");
		}
		//var_dump($_POST);exit;
		if(isset($_POST['submit']))
		{
			extract($_POST);
			$callmodel=$this->loadModel("register_model");
			$register=$callmodel->register_now($fname,$lname,$email,$pwdn,$ques_id,$ans);
			if($register==true)
			{
				header("location:". URL ."Login");
			}
			else
			{
				header("location:". URL ."Register");
			}
		}
		
	}
	
	public function valid_email()
	{
		if(isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Admin_Home");
		}
		if(isset($_POST['ajemail']))
		{
			$callmodel=$this->loadModel("register_model");
			$emailstatus=$callmodel->checkEmail($_POST['ajemail']);
			if($emailstatus==false)
			{
				unset($_SESSION['message']['already_avail']);
				$_SESSION['message']['forgot']="No account related to <font color='red'>".$_POST['ajemail']."</font>";
				echo $_SESSION['message']['not_exists'];
				unset($_SESSION['message']['not_exists']);
			}
		}
	}
	

}
?>