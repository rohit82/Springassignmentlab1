<?php 
class Login extends Controller
{
	public function index()
	{
		if(isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Admin_Home");
		}
		require APP . 'view/_templates/mheader.php';
		require APP . 'view/Login/login_index.php';
		require APP . 'view/_templates/mfooter.php';
	}
	
	public function login_user()
	{
		//var_dump($_POST);exit;
		if(isset($_POST['login']))
		{
			extract($_POST);
			$callmodel=$this->loadModel("unique_model");
			$logindata=$callmodel->grant_check("usermaster","email","password",$email,$pwd);
			if($logindata==true)
			{
				$_SESSION['moviegyan']['id']=$logindata->id;
				$_SESSION['moviegyan']['first_name']=$logindata->fname;
				header("location:". URL ."Admin_Home");
			}
			else
			{
				$_SESSION['message']['general']="Invalid email/password";
				header("location:". URL ."Login");
			}
		}
		else
		{
			$_SESSION['message']['general']="Access Denied";
			header("location:". URL ."Login");
		}
	}
	
	public function forgot_index()
	{
		if(isset($_SESSION['moviegyan']))
		{
			header("location:". URL ."Admin_Home");
		}
		require APP . 'view/_templates/mheader.php';
		require APP . 'view/Login/forgot_index.php';
		require APP . 'view/_templates/mfooter.php';
	}
	
	public function forgot_pwd()
	{
		if(isset($_POST['recover']))
		{
			$callmodel=$this->loadModel("register_model");
			$emailstatus=$callmodel->checkEmail($_POST['email']);
			if($emailstatus==false)
			{
				header("location:". URL ."Login/forgot_index");
			}
			else
			{
				unset($_SESSION['message']);
				$model=$this->loadModel("unique_model");
				$user=$model->get_security_question($_POST['email']);
				//var_dump($user);
				require APP . 'view/_templates/mheader.php';
				require APP . 'view/Login/forgot_pwd.php';
				require APP . 'view/_templates/mfooter.php';
			}
		}
		else
		{
			header("location:". URL ."Login/forgot_index");
		}
	}
	
	public function checkPassword()
	{
		//var_dump($_POST);exit;
		if(isset($_POST['ans']))
		{
			extract($_POST);
			$callmodel=$this->loadModel("unique_model");
			$check=$callmodel->grant_check('usermaster','email','security_ans',$email,$ans);
			if($check==true)
			{
				$_SESSION['recovery']['pwd']="Congrats you done it!!! Your Password is <font color='green'>".$check->password."</font>";
				echo $_SESSION['recovery']['pwd'];
				unset($_SESSION['recovery']);
			}
			else
			{
				$_SESSION['recovery']['wrong']="<font color='Red'><b>Wrong Answer</b></font>";
				echo $_SESSION['recovery']['wrong'];
				unset($_SESSION['recovery']);
			}
		}
		else
		{
			header("location:". URL ."Login/login_index");
		}
	}
}
?>