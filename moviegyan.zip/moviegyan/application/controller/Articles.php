<?php 
class Articles extends Controller
{
	public function index()
	{
		if(!isset($_SESSION['moviegyan']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page";
			header("location:". URL ."Login");
		}
		$callmodel=$this->loadModel("unique_model");
		$categories=$callmodel->get_all_data("art_categories");
		//var_dump($categories);exit;
		require APP . 'view/_templates/mheader.php';
		require APP . 'view/Articles/articles_index.php';
		require APP . 'view/_templates/mfooter.php';
	}
	
	public function Add_article()
	{
		if(!isset($_SESSION['moviegyan']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page";
			header("location:". URL ."Login");
		}
		else
		{
			//var_dump($_POST,$_FILES);exit;
			if(isset($_POST['submit_data']))
			{
				extract($_POST);
				$unique_model=$this->loadModel("unique_model");
				$data=$unique_model->get_particular_data('art_categories','cat_id',$category);
				
				$callmodel=$this->loadModel("article_model");
				$addstatus=$callmodel->add_article(trim($myear),trim($mname),trim($description),$relsd,$category,$data->cat_name,trim($director),trim($producer),trim($written_by),trim($language),trim($music_by),$_SESSION['moviegyan']['id'],$_FILES);
				if($addstatus)
				{
					$_SESSION['message']['general']="Article added successfully";
					header("location:". URL ."Articles");
				}
				else
				{
					echo "error in uploading";
				}
			}
			else
			{
				echo "something went wrong";
			}
		}
	}


	public function show($id='',$name='')
	{

		//var_dump($name);
		//var_dump(parse_url($_GET['url']));
		$name=basename($_GET['url']);
		//var_dump($name);
		//exit();
		//var_dump(ctype_space($name));exit();
		$callmodel=$this->loadModel("article_model");
		$datas=$callmodel->get_article($id,$name);
		if($datas) 
		{
			require APP . 'view/_templates/mheader.php';
			require APP . 'view/Articles/article.php';
			require APP . 'view/_templates/mfooter.php';
		} 
		else 
		{
			echo "Not found";
		}	
	}

	public function edit_article($id='')
	{
		if(!isset($_SESSION['moviegyan']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page !";
			header("location:". URL ."home");
		}
		else
		{
			$callmodel=$this->loadModel("article_model");
			$data=$callmodel->get_article_by_user($id,$_SESSION['moviegyan']['id']);
			if($data==true)
			{
				$unique_model=$this->loadModel("unique_model");
				$categories=$unique_model->get_all_data("art_categories");
				require APP . 'view/_templates/mheader.php';
				require APP . 'view/Articles/articles_index.php';
				require APP . 'view/_templates/mfooter.php';
			}
			else
			{
				$_SESSION['message']['general']="You don't have permission to edit that article !";
				header("location:". URL ."Admin_Home/mymovies");
			}
		}
	}

	public function update_article($id='')
	{
		if(!isset($_SESSION['moviegyan']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page !";
			header("location:". URL ."home");
		}
		else
		{
			if(isset($_POST['submit_data']))
			{
				//var_dump($_POST,$_FILES,$id);exit();
				extract($_POST);
				$unique_model=$this->loadModel("unique_model");
				$data=$unique_model->get_particular_data('art_categories','cat_id',$category);

				$callmodel=$this->loadModel("article_model");
				$updatestatus=$callmodel->update_article($myear,$mname,$relsd,$category,$data->cat_name,$director,$producer,$written_by,$language,$music_by,$description,$_FILES,$_SESSION['moviegyan']['id'],$id);
				if($updatestatus==true)
				{
					$_SESSION['message']['general']="Movie Updated Successfully";
					header("location:". URL ."Admin_Home/mymovies");
				}
				else
				{
					$_SESSION['message']['general']="<font color='red'>Please select photo in type JPEG,JPG,PNG or GIF</font> ";
					header("location:". URL ."Articles/edit_article/$id");
				}
			}
		}
	}

	public function delete_article($id='')
	{
		if(!isset($_SESSION['moviegyan']))
		{
			$_SESSION['message']['general']="You don't have permission to access that page !";
			header("location:". URL ."home");
		}
		else
		{
			$callmodel=$this->loadModel("article_model");
			$delstatus=$callmodel->del_article($id,$_SESSION['moviegyan']['id']);
			if($delstatus==true)
			{
				$_SESSION['message']['general']="Movie Deleted Successfully";
				header("location:". URL ."Admin_Home/mymovies");
			}
			else
			{
				$_SESSION['message']['general']="You don't have permission to delete that movie !";
				header("location:". URL ."Admin_Home/mymovies");
			}
		}
	}
}
?>