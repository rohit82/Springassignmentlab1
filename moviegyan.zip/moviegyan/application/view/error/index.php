<div class="container">
	<p>
	<?php 
	if(isset($_SESSION['error']['method'])) 
	{
		echo "<font color='red'>".$_SESSION['error']['method']." method not exists !</font>";
	}
	unset($_SESSION['error']['method']);

	if(isset($_SESSION['error']['controller'])) 
	{
		echo "<font color='red'>".$_SESSION['error']['controller']." controller not exists !</font>";
	}
	unset($_SESSION['error']['controller']);

	?></p>
    <!--<p>This is the Error-page. Will be shown when a page (= controller / method) does not exist.</p>-->
</div>
