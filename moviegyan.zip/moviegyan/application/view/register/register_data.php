<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2>Quick Links</h2>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>">Home</a></li>
									<li><a href="<?php echo URL; ?>Login">Login</a></li>
									</ul>
							</section>
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Register Data</h2>
									<span class="byline">Here you can change the name and the password only</span>
								</header>
								<p>
																	
									<?php //echo var_dump($_POST);?>
									<form action="<?php echo URL; ?>Register/register_now" method="POST">
									<table align="center" >
									<tr style="font-size:25px"><td>First Name</td><td ><input type="text" value="<?php echo $fnm; ?>" name="fname" size="30" required /></td></tr>
									<tr style="font-size:25px"><td>Last Name</td><td><input type="text" value="<?php echo $lnm; ?>" name="lname" size="30" required /></td></tr>
									<tr style="font-size:25px"><td>Email</td><td><input type="hidden" value="<?php echo $email; ?>" name="email"><?php echo $email; ?></td></tr>
									<tr style="font-size:25px"><td>Password</td><td><input type="text" value="<?php echo $cpwd; ?>"name="pwdn" size="30" required /></td></tr>
									<tr style="font-size:25px"><td>Security Question</td><td><input type="hidden" value="<?php echo $question->qid; ?>" name="ques_id"><?php echo $question->question; ?></td></tr>
									<tr style="font-size:25px"><td>Answer</td><td><input type="hidden" value="<?php echo $sec_ans; ?>" name="ans"><?php echo $sec_ans; ?></td></tr>
									<tr><td></td><td><input type="submit" value="save & continue" name="submit"></td></tr>
									</table>
									</form>
								</p>
							</section>
						</div>
					</div>
				</div>
			</div>




