<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2>Quick Links</h2>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>">Home</a></li>
									<li><a href="<?php echo URL; ?>Login">Login</a></li>
									</ul>
							</section>
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Register</h2>
									<span class="byline">Already have account? <a href="<?php echo URL; ?>Login">Login</a></span>
								</header>
								<p>
								<form action="<?php echo URL;?>Register/user_register_data" name="form1" method="post">
								<table>
								<tr><td><input type="text" name="fnm" placeholder="First Name" size="50"></p></td></tr>
								<tr><td><p><input type="text" name="lnm" placeholder="Last Name" size="50"></p></td></tr>
								<tr><td><p><input type="email" name="email" placeholder="Email" id="emailajx" size="70"></p></td></tr>
								<tr><th><div id="general_msg"></div></th></tr>
								<tr><td><p><input type="password" name="pwd" placeholder="Password" size="70" maxlength="12"></p></td></tr>
								<tr><td><p><input type="password" name="cpwd" placeholder="Confirm Password" size="70" maxlength="12"></p></td></tr>
								<tr><td><p>
								<?php 
								if(isset($questions))
								{
									?>
									<select name="question_id">
									<?php 
									foreach($questions as $question)
									{
										?>
										<option value='<?php echo $question->qid; ?>'><?php echo $question->question; ?></option>
										<?php
									}
									?>
									</select>
									<?php
								}
									
								?>
								</p></td></tr>
								<tr><td><p><input type="text" name="sec_ans" placeholder="Your Answer" size="70"></p></td></tr>
								<tr><td><p><input type="button"  onclick="checkdata()" Value="Register"></td></tr>
								<tr><td><input type="hidden"  name="register" ></td></tr>
								</table>
								</form>
								</p>
								
								<span class="byline">
								<?php 
								if(isset($_SESSION['message']['already_avail']))
								{
									echo $_SESSION['message']['already_avail'];
									unset($_SESSION['message']['already_avail']);
								}
								?>
								</span>
							</section>
						</div>
					</div>
				</div>
			</div>

<script type="text/javascript">
		$(document).ready(function(){
			$("#emailajx").keyup(function(){
				var email=$("#emailajx").val();
				$.ajax({
					type:"POST",
					url:movie_url+"Register/checkemail",
					data:{ajemail:email},
					success:function(res){
						$("#general_msg").html(res);
						}
					});
				});
			});
					
	</script>	



			
<script type="text/javascript">
function checkdata()
{
	var pwd=document.form1.pwd.value;
	msg="";
	if(document.form1.fnm.value=="")
		msg=msg+"First Name is Compulsary\n";
	else if(!document.form1.fnm.value.match(/^[A-Za-z]+$/))
		msg=msg+"First Name must have alphabet characters only\n";

	if(document.form1.lnm.value=="")
		msg=msg+"Last Name is Compulsary\n";
	else if(!document.form1.lnm.value.match(/^[A-Za-z]+$/))
		msg=msg+"Last Name must have alphabet characters only\n";

	if(document.form1.email.value=="")
		msg=msg+"Email is Compulsary\n";
	if(pwd.value=="" || pwd.length < 6 || pwd.length > 12)
		msg=msg+"Password Not Match / length must be 6 to 12 Character \n";
	
	if(document.form1.pwd.value!=document.form1.cpwd.value)
		msg=msg+"Password not match \n";
	
	if(document.form1.sec_ans.value=="")
		msg=msg+"Security answer is mandatory\n";
	if(msg!="")
		alert(msg);
	else
		document.form1.submit();
	
}
</script>

