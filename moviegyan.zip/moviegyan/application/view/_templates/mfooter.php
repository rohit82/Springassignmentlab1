<!-- Footer -->
		<div id="footer">
			<!--<section class="container">
				<header class="major">
					<h2>Connect with us</h2>
					<span class="byline">Integer sit amet pede vel arcu aliquet pretium</span>
				</header>
				<ul class="icons">
					<li class="active"><a href="#" class="fa fa-facebook"><span>Facebook</span></a></li>
					<li><a href="#" class="fa fa-twitter"><span>Twitter</span></a></li>
					<li><a href="#" class="fa fa-dribbble"><span>Pinterest</span></a></li>
					<li><a href="#" class="fa fa-google-plus"><span>Google+</span></a></li>
				</ul>
				<hr />
			</section>-->
			
			<!-- Copyright -->
			<table>
			<tr>
			<td><b>Project Incharge:</b></td>
			</tr>
			<tr>
				<td>Prof. K.R. Patil</td>
			</tr>
			
			<tr></tr>
			
			<tr>
			<th><b>Guided By:</b></th>
			</tr>
			<tr>
				<td>Prof. A.P. Chendke</td>
			</tr>
			
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr>
			<td><b>Developed By:</b></td>
			</tr>
			<tr>
				<td>
				Rajat Deshmukh<br>
				Pratik Santoshiya<br>
				Prasanna Hirlekar<br>
				Kartik Kannao<br>
				</td>
			</tr>
			</table>
				<div id="copyright">
			
				</div>			
		</div>

	</body>
</html>