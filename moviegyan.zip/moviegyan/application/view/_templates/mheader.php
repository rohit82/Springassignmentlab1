<!DOCTYPE HTML>
<!--
	Solarize by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>MovieGyan</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script>
        var movie_url = "<?php echo URL; ?>";
		</script>
		

		<script src="<?php echo URL; ?>js/jsDatePick.min.1.3.js" type="text/javascript" ></script>
		<script src="<?php echo URL; ?>js/jquery.min.js"></script>
		
		<script src="<?php echo URL; ?>js/jquery.dropotron.min.js"></script>
		<script src="<?php echo URL; ?>js/skel.min.js"></script>
		<script src="<?php echo URL; ?>js/skel-layers.min.js"></script>
		<script src="<?php echo URL; ?>js/init.js"></script>
		
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo URL; ?>js/jsDatePick_ltr.min.css" />
		<link rel="stylesheet" href="<?php echo URL; ?>css/skel.css" />
		<link rel="stylesheet" href="<?php echo URL; ?>css/style.css" />
		
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body>

		<!-- Header Wrapper -->
			<div class="wrapper style1">
			
				<!-- Header -->
					<div id="header">
						<div class="container">
								
							<!-- Logo -->
								<h1><a href="<?php echo URL; ?>" id="logo">MovieGyan</a></h1>
							
							<!-- Nav -->
								<nav id="nav">
									<ul>
										<li class="active"><a href="<?php echo URL; ?>">Home</a></li>
										<?php 
										if(isset($_SESSION['moviegyan']['first_name']))
										{
											?>
											<li><a href="<?php echo URL; ?>Admin_Home"><?php echo $_SESSION['moviegyan']['first_name'];?></a></li>
											<li><a href="">Settings</a>
											<ul>
												<li><a href="<?php echo URL; ?>Admin_Home/Admin_info_edit">Edit</a></li>
												<li><a href="<?php echo URL; ?>Admin_Home/logout">Logout</a></li>
											</ul>
											</li>
											<?php 
										}
										else
										{
										?>
											<li><a href="">Admin Panel</a>
											<ul>
												<li><a href="<?php echo URL; ?>Login">Login</a></li>
												<li><a href="<?php echo URL; ?>Register">Register</a></li>
											</ul>
											</li>
										<?php 
										}
										?>
										<!--<li><a href="left-sidebar.html">Left Sidebar</a></li>
										<li><a href="right-sidebar.html">Right Sidebar</a></li>
										<li><a href="no-sidebar.html">No Sidebar</a></li>-->
									</ul>
								</nav>
						</div>
					</div>
			</div>
		