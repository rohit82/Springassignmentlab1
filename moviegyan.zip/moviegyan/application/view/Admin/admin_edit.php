		<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									 <span class="byline">Important Links </span>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>Admin_Home/mymovies">My Movies</a></li>
									<li><a href="<?php echo URL; ?>">Home</a></li>
								</ul>
							</section>
							
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Welcome to MovieGyan</h2>
									<span class="byline">Edit Profile</span>
								</header>
								<form name="form1" action="<?php echo URL; ?>Admin_Home/update_admin" method="POST">
								<p><input type="text" name="fname" value="<?php echo $data->fname; ?>" placeholder="First Name" required/></p>
								<p><input type="text" name="lname" value="<?php echo $data->lname; ?>" placeholder="Last Name"></p>
								<p><input type="email" name="email" id="email" value="<?php echo $data->email; ?>" placeholder="Email" required/></p>
								<p><div id="general_msg"></div></p>
								<p><input type="button"  onclick="checkdata()" value="Update"></p>
								<p><input type="hidden"  name="save" ></p>
								</form>

								<p>
								<?php 
								if(isset($_SESSION['message']['general']))
								{
									echo $_SESSION['message']['general'];
									unset($_SESSION['message']['general']);
								}
								?>

								</p>
								</section>
						</div>
					</div>
				</div>
			</div>
			<script type="text/javascript">
			$(document).ready(function(){
				$("#email").keyup(function(){
					var email=$("#email").val();
					$.ajax({
						type:"GET",
						url:movie_url+"Admin_Home/checkmail/"+email,
						/*data:{ajemail:email},*/
						success:function(res){
							$("#general_msg").html(res);
							}
						});
					});
				});
					

function checkdata()
{
	msg="";
	if(document.form1.fname.value=="")
		msg=msg+"First Name is Compulsary\n";
	else if(!document.form1.fname.value.match(/^[A-Za-z]+$/))
		msg=msg+"First Name must have alphabet characters only\n";
	if(document.form1.lname.value=="")
		msg=msg+"Last Name is Compulsary\n";
	else if(!document.form1.lname.value.match(/^[A-Za-z]+$/))
		msg=msg+"Last Name must have alphabet characters only\n";

		if(msg!="")
		alert(msg);
	else
		document.form1.submit();
		}				
		</script>	