		<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									 <span class="byline">Important Links </span>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>Admin_Home/mymovies">My Movies</a></li>
									<li><a href="<?php echo URL; ?>">Home</a></li>
								</ul>
							</section>
							
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Welcome to MovieGyan</h2>
									<span class="byline">Promote your movies in free</span>
								</header>
								<p><a href="<?php echo URL; ?>Articles">Add Movie</a></p>
								</section>
						</div>
					</div>
				</div>
			</div>