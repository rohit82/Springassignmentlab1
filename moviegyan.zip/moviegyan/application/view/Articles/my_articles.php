


<!-- My movies -->
			<div class="wrapper style5">
				<section id="team" class="container">
					<header class="major">
						<h2>My Movies</h2>
						<span class="byline">Manage Your Movies</span>
					</header>
								<p style="color:red"><?php 
								if(isset($_SESSION['message']['general']))
								{
									echo $_SESSION['message']['general'];
								}
								unset($_SESSION['message']);
								?></p>

								<?php 
								if(empty($articles)) 
								{
									?>
									<p>Won't added any movie yet! add <a href="<?php echo URL; ?>Articles">Now</a></p>
									<?php
								}
								else
								{
									?>
									<div class="row">
									<?php
									foreach ($articles as $article) 
									{
										?>
											<div class="3u">
												<a href="<?php echo URL;?>Articles/show/<?php echo $article->art_id;?>/<?php echo urlencode($article->art_name); ?>" class="image"><img src="<?php echo URL;?>images/user-<?php echo $article->art_owner_id;?>/Posters/<?php echo $article->art_pic_url;?>" height="200px" width="180px" alt="<?php echo $article->art_name; ?>"></a>
												<h4><?php echo substr($article->art_name,0,25); ?></h4>
												<p><?php echo $article->rel_date; ?><br>
												<a href="<?php echo URL;?>Articles/edit_article/<?php echo $article->art_id; ?>">Edit</a>&nbsp|&nbsp<a onclick="return confirm('Are You Sure Want To Delete <?php echo $article->art_name; ?> ?')" href="<?php echo URL; ?>Articles/delete_article/<?php echo $article->art_id; ?>">Delete</a></p>
											</div>		
										<?php
									}
								}
								?>
					
						
						
					</div>
				</section>
			</div>

