<!-- Main -->

			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">
				
						<!-- Content -->

						<div id="content" class="8u skel-cell-important">
							<section>
							<h2>Description:</h2>
							<p><?php echo $datas->Description; ?></p>
							</section>
						</div>						

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2><?php echo $datas->art_name; ?></h2>
								</header>	
								<img height="300px" width="250px" title="<?php echo $datas->art_name; ?>" src="<?php echo URL; ?>images/user-<?php echo $datas->art_owner_id;?>/Posters/<?php echo $datas->art_pic_url; ?>" alt="<?php echo $datas->art_name;?>">
							</section>
							<section>
								<ul class="default">
									<?php 
									if(isset($_SESSION['moviegyan']['id']) and $_SESSION['moviegyan']['id']==$datas->art_owner_id)
									{
										?>
										<li><b><a href="<?php echo URL; ?>Articles/edit_article/<?php echo $datas->art_id; ?>">Edit</a></b></li>
										<?php 
									}
									?>
									<li><b>Category:</b> <?php echo $datas->cat_name; ?></li>
									<li><b>Director:</b> <?php echo $datas->director; ?></li>
									<li><b>Script Writer:</b> <?php echo $datas->written_by; ?></li>
									<li><b>Music Composer:</b> <?php echo $datas->music_by; ?></li>
									<li><b>Produced By:</b> <?php echo $datas->producer; ?></li>
									<li><b>Language:</b> <?php echo $datas->language; ?></li>
									<li><b>Release Date:</b> <?php echo $datas->rel_date; ?></li>
								</ul>
							</section>
						</div>

					</div>
				</div>
			</div>
