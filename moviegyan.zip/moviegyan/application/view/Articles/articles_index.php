		<!-- Main -->
		<script src="<?php echo URL; ?>js/tinymce/tinymce.min.js"></script>
			<script>tinymce.init({selector:'textarea#tiny'});</script>


			<!--ckeditor

<script type="text/javascript" src="<?php echo URL;?>ckeditor/ckeditor.js"></script>

<!--ckeditor-->

			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									 <span class="byline">Important Links </span>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>Admin_Home/mymovies">My Movies</a></li>
									<li><a href="<?php echo URL; ?>">Home</a></li>
								</ul>
							</section>
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
								<?php if(isset($data))
								{?>
									<h2>Update Movie</h2>
								<?php
								}
								else
								{?>
									<h2>Add Movie </h2>
									<span class="byline">Only Add Your Movie </span>
								<?php
								}?>
								</header>
								<p><?php 
								if(isset($_SESSION['message']['general']))
								{
									echo $_SESSION['message']['general'];
								}
								unset($_SESSION['message']);
								?></p>
								<p>
								<form onsubmit="<?php if(isset($data))echo "return true";else{?>return checkData()<?php }?>" action="<?php if(isset($data))echo URL."Articles/update_article/$data->art_id"; else{?><?php echo URL;?>Articles/Add_article <?php }?>" method="POST" enctype="multipart/form-data">
								<table>
								<tr>
								<td><p><input type="text" name="mname" value="<?php if(isset($data))echo $data->art_name;?>" placeholder="Enter Movie Name" required/></p></td>
								</tr>
								<tr>
								<td><p><input type="text" name="myear" value="<?php if(isset($data))echo $data->year;?>" placeholder="Release Year" required/></p></td>
								</tr>
								<tr>
								<td><p><input type="text"  name="relsd" value="<?php if(isset($data))echo $data->rel_date;?>" placeholder="Enter released date" id="inputField" size="12" required/></p></td>
								</tr>
								<tr><td>
								<p>
								<select name="category">
								<?php
								foreach($categories as $category)
								{
								?>
									<option <?php if(isset($data) && $data->cat_id==$category->cat_id){?> selected="" <?php }?> value="<?php echo $category->cat_id; ?>"><?php echo $category->cat_name; ?></option>
									<?php 
								}	?>
								</select>	
								</p>
								</td></tr>
								<tr>
								<td><p><input type="File" name="photo" id="photo" onchange="<?php if(isset($data))echo "return true"; else {?>return fileValidate()<?php }?>" <?php if(!isset($data))echo "required"?> /><br><?php if(isset($data)){?><img height="75px" width="75px" src="<?php echo URL; ?>images/user-<?php echo $data->art_owner_id; ?>/Posters/<?php echo $data->art_pic_url; ?>"><?php }?></p></td>
								</tr>
								<tr>
									<td><p><textarea rows="2" style="resize:none" name="director" placeholder="Directed By" ><?php if(isset($data))echo $data->director;?></textarea></p></td>
								</tr>

								<tr>
									<td><p><textarea rows="2" style="resize:none" name="producer" placeholder="Produced By" ><?php if(isset($data))echo $data->producer;?></textarea></p></td>
								</tr>

								<tr>
									<td><p><textarea rows="2" style="resize:none" name="written_by" placeholder="Script Writer" ><?php if(isset($data))echo $data->written_by;?></textarea></p></td>
								</tr>

								<tr>
									<td><p><textarea rows="2" style="resize:none" name="language" placeholder="Language" ><?php if(isset($data))echo $data->language;?></textarea></p></td>
								</tr>

								<tr>
									<td><p><textarea rows="2" style="resize:none" name="music_by" placeholder="Music Composer" /><?php if(isset($data))echo $data->music_by;?></textarea></p></td>
								</tr>

								<tr>
								<td><p><textarea id="tiny" placeholder="Description" name="description"><?php if(isset($data))echo $data->Description;?></textarea></p></td>
								</tr>
								<tr>
								<td><p><input type="submit" name="submit_data" value="<?php if(isset($data))echo 'Update';else echo 'Add'; ?>"/></td>
								</tr>
								</table>
								</form>
								</p>
								
									

								</section>
						</div>
					</div>
				</div>
			</div>
			<script type="text/javascript">

								var count=0;
								function checkData()
								{
									var msg="";
									count=1;
									if (fileValidate()!=true)
										msg=msg+"Please select FILE in type JPG ,JPEG ,GIF or PNG\n";
									if(msg!="")
									{
										alert(msg);
										return false;
									}
									else
										return true;
								}

								function fileValidate()
								{
									
										var filename=document.getElementById('photo').value;
										var extension=filename.substring(filename.lastIndexOf('.')+1).toLowerCase();
										if(extension=='jpg' || extension=='jpeg' || extension=='gif' || extension=='png')
											return true;
										else
										{
											if(count==0)
												alert("Please select FILE in type JPG ,JPEG ,GIF or PNG\n");
										}
									
								}


									window.onload = function(){
										new JsDatePick({
											useMode:2,
											target:"inputField",
											dateFormat:"%d-%M-%Y"
											/*selectedDate:{				This is an example of what the full configuration offers.
												day:5,						For full documentation about these settings please see the full version of the code.
												month:9,
												year:2006
											},
											yearsRange:[1978,2020],
											limitToToday:false,
											cellColorScheme:"beige",
											dateFormat:"%m-%d-%Y",
											imgPath:"img/",
											weekStartDay:1*/
										});
									};
								</script>