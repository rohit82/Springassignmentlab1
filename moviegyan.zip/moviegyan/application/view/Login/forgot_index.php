		
		<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2>Quick Links</h2>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>">Home</a></li>
									<li><a href="<?php echo URL; ?>Login">Login</a></li>
									<li><a href="<?php echo URL; ?>Register">Register</a></li>
									</ul>
							</section>
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Forgot Password</h2>
									<span class="byline">Please Enter Your Valid Email</span>
								</header>
								<p>
								<form name="f1" action="<?php echo URL;?>Login/forgot_pwd" method="post" >
								<table >
								<tr><td><input type="email" name="email" id="emj" size="15" placeholder="Email" required/></p></td></tr>
								<tr><td><p><input type="submit" value="Recover Password">    <a href="<?php echo URL; ?>Login">Login</a></p></td></tr>
								<tr><td colspan="2"><div id="general_msg"></div></td></tr>
								<tr><td><input type="hidden" name="recover" ></td></tr>
								<tr>
								<td colspan="2">
									<?php 
									//var_dump($_SESSION);
										if(isset($_SESSION['message']['forgot']))
										{						
											echo $_SESSION['message']['forgot'];
											unset($_SESSION['message']['forgot']);
										}
									?>
								</td></tr>
								</table>
								</form>
								</p>
								<script type="text/javascript">
								$(document).ready(function(){
									$('#emj').keyup(function(){
									var email=$('#emj').val();
									if($.trim(email!=""))
									{
										$.ajax({
											type:"POST",
											url:movie_url+"Register/valid_email",
											data:{ajemail:email},
											success:function(res)
											{
												$('#general_msg').html(res);
											}
										});
									}
									});
								});
								</script>
							</section>
						</div>
					</div>
				</div>
			</div>