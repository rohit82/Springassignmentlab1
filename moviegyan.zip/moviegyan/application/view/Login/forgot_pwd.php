		
		<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2>Quick Links</h2>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>">Home</a></li>
									<li><a href="<?php echo URL; ?>Login">Login</a></li>
									<li><a href="<?php echo URL; ?>Register">Register</a></li>
									</ul>
							</section>
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Forgot Password</h2>
									<span class="byline">Answer your security question</span>
								</header>
								<p><h3><?php echo $user->question; ?></h3></p>
								<p>
								<input type="text" name="ans" id="ans" placeholder="Please Answer this question" required/>
								<input type="hidden" name="email" id="email" value="<?php echo $_POST['email']; ?>">
								</p>
								<p><input type="submit" id="hit" value="Submit" ></p>
								<p><div id="checked_ans"></div></p>
							</section>
							<script type="text/javascript">
							$(document).ready(function(){
								$('#hit').on("click",function(){
									var ajans=$('#ans').val();
									var ajemail=$('#email').val();
									$.ajax({
										type:"POST",
										url:movie_url+"Login/checkPassword",
										data:{ans:ajans,email:ajemail},
										success:function(data)
										{
											$('#checked_ans').html(data);
										}
									});
								});
							});
							</script>
						</div>
					</div>
				</div>
			</div>