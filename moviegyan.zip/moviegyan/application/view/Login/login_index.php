<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2>Quick Links</h2>
								</header>									
								<ul class="default">
									<li><a href="<?php echo URL; ?>">Home</a></li>
									<li><a href="<?php echo URL; ?>Register">Register</a></li>
								</ul>
							</section>
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Login</h2>
									<span class="byline">Don't have Account Register <a href="<?php echo URL; ?>Register">Here</a></span>
								</header>
								<p>
								<form name="f1" action="<?php echo URL; ?>Login/login_user" method="post" >
								<table >
								<tr><td><input type="email" name="email"  size="15" placeholder="Email"  required/></p></td></tr>
								<tr><td><p><input type="password" name="pwd" size="15" placeholder="Password" required/></p></td></tr>
								<tr><td><p><input type="button" id="login" value="Login" onclick="validate()" >     <a href="<?php echo URL; ?>Login/forgot_index">Forgot Password</a></p></td></tr>
								<tr><td><input type="hidden" name="login" ></td></tr>
								<tr>
								<p><td colspan="2">
									<?php 
										if(isset($_SESSION['message']['general']))
										{						
											echo $_SESSION['message']['general'];
											unset($_SESSION['message']);
										}
									?>
								</td></tr>
								</table>
								</form>
								</p>
							</section>
						</div>
					</div>
				</div>
			</div>
			
			
			
			
		



<script type="text/javascript">
function validate()
{
	msg="";
	if(document.f1.email.value=="")
		msg=msg+"Please enter email\n";
	if(document.f1.pwd.value=="")
		msg=msg+"Please enter Password";
	if(msg!="")
		alert(msg);
	else
		document.f1.submit();
		
}
</script>		
			
			
			
			
			
			
			
			