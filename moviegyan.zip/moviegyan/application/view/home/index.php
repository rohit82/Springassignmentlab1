<!-- Main -->
			<div id="main" class="wrapper style4">
				<div class="container">
					<div class="row">

						<!-- Sidebar -->
						<div id="sidebar" class="4u">
							<section>
								<header class="major">
									<h2>Quick Links</h2>
								</header>									
								<ul class="default">
										<?php 
										foreach ($datas as $data) 
										{
											?>
											<li><a href="<?php echo URL; ?>home/category/<?php echo $data->cat_id; ?>"><?php echo $data->cat_name; ?></a></li>
											<?php 
										}
										?>
										

									<?php 
									if(!isset($_SESSION['moviegyan']))
									{ 
										?>
										<li><a href="<?php echo URL; ?>Login">Login</a></li>
										<li><a href="<?php echo URL; ?>Register">Register</a></li>
										<?php
									}?>
								</ul>
							</section>			
						</div>

						<!-- Content -->
						<div id="content" class="8u skel-cell-important">
							<section>
								<header class="major">
									<h2>Search</h2>
									<span class="byline"><input type="text" name="movie" placeholder="Search Movie" id="movie"></span>
								</header>
								<script type="text/javascript">
										$(document).ready(function(){
											$("#movie").keyup(function(){
												var mname=$("#movie").val();
												$.ajax({
													type:"POST",
													url:movie_url+"Home/search_movie",
													data:{keyword:mname},
													success:function(res){
														$("#mov").html(res);
													}
												});
											});
										});
								</script>
								<p style="color:red"><?php 
								if(isset($_SESSION['message']['general']))
								{
									echo $_SESSION['message']['general'];
								}
								unset($_SESSION['message']);
								?></p>
							<div id="mov" class="row">	
							<?php 
							 if(isset($records) and !empty($records))
							 {
								foreach ($records as $datas) 
								{
									//var_dump($datas);
									?>
									<div class="3u">
										<a href="<?php echo URL; ?>Articles/show/<?php echo $datas->art_id; ?>/<?php echo urlencode($datas->art_name); ?>" class="image"><img height="200px" width="180px" title="<?php echo $datas->art_name; ?>" src="<?php echo URL; ?>images/user-<?php echo $datas->art_owner_id;?>/Posters/<?php echo $datas->art_pic_url; ?>" alt="<?php echo $datas->art_name;?>"></a>
										<h5><a href="<?php echo URL; ?>Articles/show/<?php echo $datas->art_id; ?>/<?php echo urlencode($datas->art_name); ?>" title="<?php echo $datas->art_name; ?>"><?php echo substr($datas->art_name,0,18);?></a></h5>
										<p><?php echo $datas->rel_date;?></p>
									</div>
									<?php
								}
							}
							
								?>
							
							</div>
							</section>
						</div>
					</div>
				</div>
			</div>



		
		
		
		