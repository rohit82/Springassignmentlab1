




<?php 
	foreach ($records as $datas) 
	{
		//var_dump($datas);
		?>
		<div class="3u">
			<a href="<?php echo URL; ?>Articles/show/<?php echo $datas->art_id; ?>/<?php echo urlencode($datas->art_name); ?>" class="image"><img height="200px" width="180px" title="<?php echo $datas->art_name; ?>" src="<?php echo URL; ?>images/user-<?php echo $datas->art_owner_id;?>/Posters/<?php echo $datas->art_pic_url; ?>" alt="<?php echo $datas->art_name;?>"></a>
			<h5><a href="<?php echo URL; ?>Articles/show/<?php echo $datas->art_id; ?>/<?php echo urlencode($datas->art_name); ?>" title="<?php echo $datas->art_name; ?>"><?php echo substr($datas->art_name,0,12);?></a></h5>
			<p><?php echo $datas->rel_date;?></p>
		</div>
		<?php
	}
	?>
				