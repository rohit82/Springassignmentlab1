<?php 
class article_model
{
	function __construct($db)
	{
		try
		{
			$this->db=$db;
		}catch(PDOEXception $e)
		{
			exit("connection cannot established");
		}
	}	
 												
	public function add_article($year,$nm,$desc,$rdate,$catid,$cat_name,$director,$producer,$written_by,$language,$music_by,$id,$img)
	{
		//var_dump($decade);
		$lastno=$year%10;
		$lastno=$lastno*0;
		$remains=$year/10;
		$remains=substr($remains,0,3).$lastno;
		//var_dump($lastno,$remains,$decade);
		$years=array();
		$j=0;
		for ($i=$remains; $i<=$remains+9 ; $i++) 
		{ 

			$years[$j]=$i;
			$j++;
		}
		$decade=implode(',',$years);
		
		//exit($yr);
		/*$sqls="select * from art_categories where cat_id=".$catid." ";
		$querys=$this->db->prepare($sqls);
		$querys->execute();
		$data=$querys->fetch();*/

		//var_dump($nm,$desc,$rdate,$catid,$director,$producer,$written_by,$language,$id,$img);exit();
		$src=$img['photo']['tmp_name'];
		$pname="photo_".time().".jpg";
		$dest="images/USER-$id/Posters/".$pname;
		move_uploaded_file($src,$dest);
		$sql="insert into articles 
			(
			decade,
			year,
			art_name,
			Description,
			director,
			producer,
			written_by,
			language,
			music_by,
			rel_date,
			posted,
			art_owner_id,
			cat_id,
			category,
			art_pic_url
			)
		values 
		(
		 ".$this->db->quote($decade).",
		 ".$this->db->quote($year).",
		 ".$this->db->quote($nm).",
		 ".$this->db->quote($desc).",
		 ".$this->db->quote($director).",
		 ".$this->db->quote($producer).",
		 ".$this->db->quote($written_by).",
		 ".$this->db->quote($language).",
		 ".$this->db->quote($music_by).",
		 ".$this->db->quote($rdate).",
		 now(),
		 ".$id.",
		 ".$catid.",
		 ".$this->db->quote($cat_name).",
		 '".$pname."'
		 )";
		//var_dump($sql);exit;
		$query=$this->db->prepare($sql);
		return $query->execute();
	}
	
	public function get_my_articles($id='')
	{
		$sql="select * from articles where art_owner_id=".$id." order by art_id desc";
		//var_dump($sql);exit;
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetchall();
	}


	public function search($keyword="")
	{
		$sql="select * from articles where 
			art_name like '%".$keyword."%' || 
			rel_date like '%".$keyword."%' ||
			Description like '%".$keyword."%' || 
			written_by like '%".$keyword."%' ||
			producer like '%".$keyword."%' ||
			director like '%".$keyword."%' ||
			music_by like '%".$keyword."%' ||
			language like '%".$keyword."%' ||
			category like '%".$keyword."%' ||
			decade like '%".$keyword."%'
			";
		//var_dump($sql);exit;
		$query=$this->db->prepare($sql);
		$query->execute();
		if ($query->rowCount()>0) 
		{
			return $query->fetchall();	
		}
		else
		{
			return false;
		}
	}

	public function get_article($id='',$name='')
	{
		//var_dump($name);exit();
		$sql="select * from articles,art_categories 
				where (articles.art_id='".$id."' && articles.art_name=".$this->db->quote($name).") && articles.cat_id=art_categories.cat_id";
		//var_dump($sql);exit();
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetch();
	}

	public function get_article_by_user($id='',$uid='')
	{
		$sql="select * from articles where art_id=".$id." and art_owner_id=".$uid."";
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetch();
	}

	public function update_article($year='',$nm='',$relsd='',$catg='',$cat_name='',$director='',$producer='',$written_by='',$language='',$music_by='',$description='',$img='',$uid='',$id='')
	{
		$lastno=$year%10;
		$lastno=$lastno*0;
		$remains=$year/10;
		//var_dump($remains,stripos($remains,'.'));
		$remains=intval($remains).$lastno;
		//var_dump($lastno,$remains);exit();
		$years=array();
		$j=0;
		for ($i=$remains; $i<=$remains+9 ; $i++) 
		{ 

			$years[$j]=$i;
			$j++;
		}
		$decade=implode(',',$years);

		$sql="update articles set 
			art_name=".$this->db->quote($nm).",
			decade=".$this->db->quote($decade).",
			year=".$this->db->quote($year).", 
			rel_date=".$this->db->quote($relsd).",
			cat_id='".$catg."', 
			category=".$this->db->quote($cat_name).",
			director=".$this->db->quote($director).", 
			producer=".$this->db->quote($producer).", 
			written_by=".$this->db->quote($written_by).", 
			language=".$this->db->quote($language).",
			music_by=".$this->db->quote($music_by).",
			Description=".$this->db->quote($description)."
			where art_owner_id=".$uid." && art_id=".$id." ";
		$query=$this->db->prepare($sql);
		$query->execute();
		if($img['photo']['size']!=0 AND $img['photo']['name']!='') 
		{
			$extension=array('image/jpeg',
							 'image/jpg',
							 'image/png',
							 'image/gif');
			if(in_array($img['photo']['type'],$extension))
			{
				//file uploading
				$name="photo_".time().".jpg";
				$src=$img['photo']['tmp_name'];
				$dest="images/user-$uid/Posters/".$name;
				move_uploaded_file($src,$dest);
				
				//deleted file from user's folders
				$info=$this->get_article_by_user($id,$uid);
				unlink("images/user-$uid/Posters/$info->art_pic_url");
				
				//updated record in the database
				$sqlu="update articles set art_pic_url='".$name."' where art_owner_id=".$uid." && art_id=".$id." ";
				$queryu=$this->db->prepare($sqlu);
				$queryu->execute();
				
				return true;
			}
			else
			{
				return false;
			}
		} 
		else 
		{
			return true;
		}
	}

	public function del_article($id='',$uid='')
	{

		
		$data=$this->get_article_by_user($id,$uid);
		//var_dump($data);exit();

		$sql="delete from articles where art_id=".$id." and art_owner_id=".$uid." ";
		$query=$this->db->prepare($sql);
		$query->execute();
		if($query->rowCount()==1)
		{
			unlink("images/user-$uid/Posters/$data->art_pic_url");
			return true;
		}
		else
			return false;
	}

	public function get_articles_by_category($id='')
	{
		$sql="select * from articles where cat_id=".$id."";
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetchall();
	}
}
?>