<?php 
class admin_model
{
	function __construct($db)
	{
		try
		{
			$this->db=$db;
		}catch(PDOEXception $e)
		{
			exit("cannot connect to database");
		}
	}
	
	public function logout()
	{
		if(isset($_SESSION['moviegyan']))
		{
			unset($_SESSION['moviegyan']);
			return true;
		}
		else
			return false;
	}

    public function	checkmail($tbl='',$clm1='',$clm2='',$val1='',$val2='')
    {
    	$sql="select * from $tbl where $clm1='".$val1."' and $clm2!='".$val2."'";
    	$query=$this->db->prepare($sql);
    	$query->execute();
    	if($query->rowCount()>0)
    		return false;
    	else
    		return true;
    }

    public function update_user_admin($fname='',$lname='',$email='',$id='')
    {
    	$sql="update usermaster set fname=".$this->db->quote($fname).",lname=".$this->db->quote($lname).", email=".$this->db->quote($email)." where id=".$id." ";
    	$query=$this->db->prepare($sql);
        $query->execute();
        $_SESSION['moviegyan']['first_name']=$fname;
        return true;
    }
}
?>