<?php 
class register_model
{
	function __construct($db)
	{
		try
		{
			$this->db=$db;
		}catch(PDOException $e)
		{
			exit("Connection cannot established");
		}
	}
	
	public function checkEmail($email="")
	{
		$sql="select * from usermaster where email='".$email."'";
		$query=$this->db->prepare($sql);
		$query->execute();
		if($query->rowCount()>0)
		{
			$_SESSION['message']['already_avail']="<font color='red'>".$email."</font> already exists . Please select another one";
			return true;
		}
		else
		{
			$_SESSION['message']['not_exists']="No account related to <font color='red'>".$email."</font>";
			return false;
		}
	}
	
	public function register($fnm,$lnm,$email,$cpwd)
	{
		$sql="select * from usermaster where email='".$email."'";
		$query=$this->db->prepare($sql);
		$query->execute();
		if($query->rowCount()==0)
		{
			return true;
		}
		else
		{
			$_SESSION['mesage']['already_avail']="".$email." already exists . Please select another one";
			return false;
		}
	}
	
	public function register_now($fname,$lname,$email,$pwdn,$qid,$ans)
	{
		$sql="select * from usermaster where email='".$email."'";
		$query=$this->db->prepare($sql);
		$query->execute();
		if($query->rowCount()==0)
		{
			$sql="insert into usermaster (fname,lname,email,password,security_que_id,security_ans) values('".$fname."','".$lname."','".$email."','".$pwdn."',".$qid.",'".$ans."')";
			$query=$this->db->prepare($sql);
			$query->execute();
			$id=$this->db->lastInsertId();
			if(!file_exists("images/user-$id"))
			{
				mkdir("images/user-$id");
				mkdir("images/user-$id/Posters");
			}
			$_SESSION['message']['general']="You Are Registered Successfully . Please Login ";
			return true;
		}
		else
		{
			$_SESSION['message']['already_avail']="".$email." already exists . Please select another one";
			return false;
		}	
	}
}
?>