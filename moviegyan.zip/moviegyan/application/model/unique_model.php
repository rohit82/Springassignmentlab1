<?php 
class unique_model
{
	function __construct($db)
	{
		try
		{
			$this->db=$db;
		}
		catch(PDOEXception $e)
		{
			exit("Cannot established connection");
		}
	}
	
	public function get_all_data($tbl='')
	{
		$sql="select * from $tbl";
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetchall();
	}
	
	public function get_particular_data($tbl='',$clm='',$val='')
	{
		//var_dump($tbl,$clm,$val);exit;
		$sql="select * from $tbl where $clm='".$val."'";
		//var_dump($sql);exit;
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetch();
	}
	
	public function get_security_question($email='')
	{
		$sql="select * from security_question 
				where qid=(select security_que_id from usermaster 
					where email='".$email."')";
		//var_dump($sql);exit;
		$query=$this->db->prepare($sql);
		$query->execute();
		return $query->fetch();
	}
	
	public function grant_check($tbl='',$clm1='',$clm2='',$val1='',$val2='')
	{
		$sql="select * from $tbl where $clm1='".$val1."' and $clm2='".$val2."'";
		//var_dump($sql);exit;
		$query=$this->db->prepare($sql);
		$query->execute();
		if($query->rowCount()==1)
		{
			return $query->fetch();
		}
		else
		{
			return false;
		}
	}

}
?>